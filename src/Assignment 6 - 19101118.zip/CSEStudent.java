package Assignment6;

public class CSEStudent extends Student {
    public CSEStudent(String  name, int ID, int semester, String dept) {
        super(name,ID,semester,dept);
    }

    public CSEStudent(double creditInThisCourse, double cgpainThisCourse) {
        super(creditInThisCourse,cgpainThisCourse);
    }

    public void print(int k, String[] courseArray){
        super.print(k,courseArray);
    }
}

