package Assignment6;

public class MNSStudent extends Student {
    public MNSStudent(String  name, int ID, int semester, String dept) {
        super(name,ID,semester,dept);
    }

    public MNSStudent(double creditInThisCourse, double cgpainThisCourse) {
        super(creditInThisCourse,cgpainThisCourse);
    }

    public void print(int k, String[] courseArray){
        super.print(k,courseArray);
    }
}


