package Assignment6;

public class BBSStudent extends Student {
    public BBSStudent(String  name, int ID, int semester, String dept) {
        super(name,ID,semester,dept);
    }

    public BBSStudent(double creditInThisCourse, double cgpainThisCourse) {
        super(creditInThisCourse,cgpainThisCourse);
    }

    public void print(int k, String[] courseArray){
        super.print(k,courseArray);
    }
}
