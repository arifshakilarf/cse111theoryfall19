package Assignment4;

public class Course {
    public String name = " ";

    public Course(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}


