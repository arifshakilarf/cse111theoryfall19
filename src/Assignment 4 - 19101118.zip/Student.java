package Assignment4;

import java.util.ArrayList;
public class Student {
    public String name=" ";
    public static int id=-1;
    public String typeOfStudent="Regular Student";
    private int ID=0;
    public static int preUni=0;
    public String university="null";

    public Student(String name){
        this.name=name;
        this.id++;
        ID=id;
    }

    public Student(String name,String typeOfStudent){
        this.name=name;
        preUni=1;
        this.typeOfStudent=typeOfStudent;
        this.id++;
        ID=id;
    }

    ArrayList <Course> course=new ArrayList <Course> ();

    public void addCourse(Course c1, Course c2, Course c3, Course c4){
        course.add(c1);
        course.add(c2);
        course.add(c3);
        course.add(c4);
    }


